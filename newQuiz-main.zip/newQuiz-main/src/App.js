import logo from './logo.svg';
import './App.css';
import Approute from './route/router';
import Addquiz from './screen/dScreen/addQuiz';

function App() {
  return (
<>
{/* <Approute /> */}
<Addquiz/>
</>
  );
}

export default App;

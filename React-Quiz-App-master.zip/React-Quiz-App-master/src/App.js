import logo from './logo.svg';
import './App.css';
import Approute from './route/router';

function App() {
  return (
<>
<Approute />
</>
  );
}

export default App;

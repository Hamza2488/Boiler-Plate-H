import './App.css';
import AppRoutering from './config/AppRoutering';

function App() {
  return (
    <>
      <AppRoutering />
    </>
  );
}

export default App;

import React from 'react';
import '../../App.css'
import DrawerAppBar from '../../components/Navbar';

const Admin = () => {
    return (
        <div>
            <DrawerAppBar />
        </div>
    )
}

export default Admin

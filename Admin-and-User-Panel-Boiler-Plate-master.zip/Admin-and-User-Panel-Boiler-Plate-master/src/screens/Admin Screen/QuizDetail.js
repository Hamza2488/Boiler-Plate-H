import React from 'react'

const QuizDetail = () => {
    return (
        <div>
            <h1>Quiz Detail</h1>
        </div>
    )
}

export default QuizDetail;